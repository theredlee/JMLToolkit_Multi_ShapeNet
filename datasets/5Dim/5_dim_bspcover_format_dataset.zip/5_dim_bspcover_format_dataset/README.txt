Data statistic
	a. Train:test ratio: 80:20
	b. Number of patients in train dataset: 361
	c. Number of patients in test dataset: 91
	d. HCC (label) 0:1 ratio: 226:226
	f. Total number of patient (real value): 452